        </div>
        <script src="<?php echo base_url(); ?>webroot/js/bootstrap.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/js/bootbox.min.js"></script>      
        <script src="<?php echo base_url(); ?>webroot/js/app.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/js/jquery-ui.js"></script>
        <script src="<?php echo base_url(); ?>webroot/js/moment.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/plugins/timepicker/bootstrap-timepicker.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/plugins/fullcalendar/fullcalendar.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/plugins/datatables/jquery.dataTables.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/plugins/datatables/dataTables.bootstrap.min.js"></script>
        <script src="<?php echo base_url();?>webroot/js/dataencrypt.js" type="text/javascript"></script>
        <script src="<?php echo base_url();?>webroot/js/bootstrap-select.min.js"></script>
        <script src="<?php echo base_url(); ?>webroot/js/summernote-bs4.js"></script>
        <script src="<?php echo base_url(); ?>webroot/js/nestable/jquery.nestable.js"></script>
        <script src="<?php echo base_url();?>webroot/js/toster.min.js"></script>
        <script type="text/javascript">
            $("#msg_div").fadeOut(10000);  
            $(function(){            
                $( ".current_date_val" ).datepicker({
                    dateFormat : 'yy-mm-dd',
                    changeMonth : true,
                    changeYear : true,  
                    minDate:new Date(),      
                });
                $( ".date_val" ).datepicker({
                    dateFormat : 'yy-mm-dd',
                    changeMonth : true,
                    changeYear : true,  
                });
                $(".timepicker").timepicker({
                    showInputs: false,
                    minuteStep: 5,
                    showMeridian: false,
                });
                $.fn.dataTable.ext.errMode = 'none';
                $('#example').DataTable({
                    "paging": true,
                    "lengthChange": true,
                    "searching": true,
                    "ordering": true,
                    "info": true,
                    "autoWidth": false
                });
                $('#example_new').DataTable({
                    "paging": false,
                    "lengthChange": false,
                    "searching": false,
                    "ordering": true,
                    "info": false,
                    "autoWidth": false
                });
                $('#example_scroll').DataTable({
                   "paging": false,
                   "lengthChange": false,
                   "searching": false,
                   "ordering": false,
                   "info": false,
                   "autoWidth": false,
                   "scrollX": true
                });
            });
            $(document).ready(function(){
                $('.summernote').summernote({
                    height: '200px',
                    placeholder: 'text here....',
                    fontNames: ['Arial', 'Arial Black', 'Khmer OS'],
                });
                $("#content").summernote();
                $('.dropdown-toggle').dropdown();

            });
            $.validate({
                modules : 'date, security, file',
                onModulesLoaded : function() {}
            });
            var table = $('.box-body').find('table');
            if(!table.parent('div').hasClass('table-responsive')){
                table.wrap('<div class="table-responsive"></div>');
            }
            if($('table thead tr').hasClass('label-primary'));{
                $('table thead tr').removeClass('label-primary')
            }
        </script>
        <script type="text/javascript" src="<?php echo base_url();?>webroot/plugins/tinymce/tinymce.min.js"></script>
        <script type="text/javascript">
            tinymce.init({
            selector: "textarea.tiny_textarea",
            plugins :"advlist autolink link image lists charmap print preview code fullscreen textcolor table media",
            tools: "inserttable", 
            relative_urls: false,
            toolbar: [ "undo redo | styleselect | bold italic | link image | bullist numlist outdent indent | alignleft aligncenter alignright alignjustify  forecolor backcolor | fontsizeselect | sizeselect | fontselect", ]
            });
            tinymce.init({
                // fontsize_formats: "1pt 2pt 3pt 4pt 5pt 6pt 7pt",
                selector: "textarea.tiny_textarea_disabled",
                relative_urls: false,            
                readonly : 1
            });     
            var table = $('.box-body').find('table');
            if(!table.parent('div').hasClass('table-responsive')) 
            {
                table.wrap('<div class="table-responsive"></div>');
            }
            if($('table thead tr').hasClass('label-primary'));
            {
                $('table thead tr').removeClass('label-primary')
            }
        </script>
        <script type="text/javascript">
            var placeSearch, autocomplete;
            var componentForm = {
              street_number: 'short_name',
              route: 'long_name',
              locality: 'long_name',
              administrative_area_level_1: 'short_name',
              country: 'long_name',
              postal_code: 'short_name',
              txtLat: 'txtLat',
              txtLng: 'short_name'
            };
            var map;
            var marker;

            function initAutocomplete() {
              var mapCanvas = document.getElementById("map");
              var myCenter = new google.maps.LatLng(62, -110.0);
              var mapOptions = {
                center: myCenter,
                zoom: 3
              };
              map = new google.maps.Map(mapCanvas, mapOptions);
              marker = new google.maps.Marker({
                position: myCenter,
                draggable: true,
                animation: google.maps.Animation.BOUNCE
              });
              google.maps.event.addListener(marker, 'click', function() {
                map.setZoom(2 * mapOptions.zoom);
                map.setCenter(marker.getPosition());
              });

               /*google.maps.event.addListener(marker, 'dragend', function (evt) {
                            $("#txtLat").val(evt.latLng.lat().toFixed(6));
                            $("#txtLng").val(evt.latLng.lng().toFixed(6));

                            map.panTo(evt.latLng);
                        });*/
              marker.setMap(map);

              google.maps.event.addListener(map, "click", function(e) {

                //lat and lng is available in e object
                placeMarker(map, e.latLng);
                // var latLng = e.latLng;
                // console.log("lat" + latLng.lat() + "long" + latLng.lng());
              });

              function placeMarker(map, location) {

                marker.setPosition(location);
                var txtLat = location.lat();
                $("#txtLat").val(txtLat);
                var txtLng =location.lng();
                $("#txtLng").val(txtLng);

                var infowindow = new google.maps.InfoWindow({
                  content: 'Latitude: ' + location.lat() + '<br>Longitude: ' + location.lng()
                });
                infowindow.open(map, marker);
              }

              // Create the autocomplete object, restricting the search to geographical
              // location types.
              autocomplete = new google.maps.places.Autocomplete(
                /** @type {!HTMLInputElement} */
                (document.getElementById('autocomplete')), {
                  types: ['geocode']
                });

              // When the user selects an address from the dropdown, populate the address
              // fields in the form.
              autocomplete.addListener('place_changed', fillInAddress);
            }

            function fillInAddress() {
              // Get the place details from the autocomplete object.
              var place = autocomplete.getPlace();
              if (marker && marker.setMap)
                marker.setMap(null);
              marker = new google.maps.Marker({
                position: place.geometry.location,
                animation: google.maps.Animation.BOUNCE,
                map: map
              });
              var txtLat = place.geometry.location.lat();
                $("#txtLat").val(txtLat);
                var txtLng =place.geometry.location.lng();
                $("#txtLng").val(txtLng);
              marker.setPosition(place.geometry.location);
              map.setCenter(place.geometry.location);
              if (place.geometry.viewport)
                map.fitBounds(place.geometry.viewport);

              for (var component in componentForm) {
                document.getElementById(component).value = '';
                document.getElementById(component).disabled = false;
              }

              // Get each component of the address from the place details
              // and fill the corresponding field on the form.
              for (var i = 0; i < place.address_components.length; i++) {
                var addressType = place.address_components[i].types[0];
                if (componentForm[addressType]) {
                  var val = place.address_components[i][componentForm[addressType]];
                  console.log(val);
                  document.getElementById(addressType).value = val;
                }
              }
            }

            // Bias the autocomplete object to the user's geographical location,
            // as supplied by the browser's 'navigator.geolocation' object.
            function geolocate() {
              if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(function(position) {
                  var geolocation = {
                    lat: position.coords.latitude,
                    lng: position.coords.longitude
                  };
                  console.log(geolocation.lat);
                });
              }
            }
            google.maps.event.addDomListener(window, "load", initAutocomplete);
        </script>
    </body>
</html>