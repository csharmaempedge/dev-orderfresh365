<?php
class Order_model extends CI_Model 
{
	function __construct()
	{
       parent::__construct();
	   $this->load->database();
	}
    /*========================================*/
    private function _get_query($param1 = NULL)
    {  
        $sql = array();
        $f_sql = '';
        $order_by = 'order_id DESC';
        $start_date = '';
        $end_date = '';
        $patient_id = $this->data['session']->user_id;
        if($patient_id !='2')
        {
            $sql[] = "patient_id = '".$patient_id."'";
        }
        if(isset($_POST['filter_by']) && $_POST['filter_by'] != '')
        {
            if($_POST['filter_by']['start_date'] != '')
            {
                $start_date   = $_POST['filter_by']['start_date'];
            }
            if($_POST['filter_by']['end_date'] != '')
            {
                $end_date   = $_POST['filter_by']['end_date'];
            }
            if(!empty($start_date) && !empty($end_date))
            {
                $start_date = date('Y-m-d', strtotime($start_date));
                $end_date   = date('Y-m-d', strtotime($end_date));
                $start_date = $start_date;
                $sql[] = "order_create_date >= '".$start_date."'";
                $end_date = $end_date;
                $sql[]  = "order_create_date <= '".$end_date."'";


            }
        }
        if(sizeof($sql) > 0)
        $f_sql = implode(' AND ', $sql);

        
        if($param1 == 'show_list' && isset($_POST["length"]) && $_POST["length"] != -1)  
        {  
            $limit = $_POST['length'];
            $offset = $_POST['start'];
            if($f_sql)
            {
                return "SELECT *  FROM (`tbl_order`) WHERE $f_sql ORDER BY $order_by LIMIT $limit OFFSET $offset";
            }
            else
            {
                return "SELECT *  FROM (`tbl_order`) ORDER BY $order_by LIMIT $limit OFFSET $offset";        
            }
        }  
        else
        {
            if($f_sql)
            {
                return "SELECT *  FROM (`tbl_order`) WHERE $f_sql ORDER BY $order_by";
            }
            else
            {
                return "SELECT *  FROM (`tbl_order`) ORDER BY $order_by";    
            }
        }
    }

    function count_filtered()
    {
       $query = $this->_get_query();
       return $result = $this->db->query($query)->num_rows();
    }

    public function getAllOrderList()
    {
        $query = $this->_get_query('show_list');
        return $result = $this->db->query($query)->result();
    }

    public function gettotalOrderQty($patient_id, $order_id)
    {
        $this->db->select('SUM(total_qty) as qty');
        $this->db->from('tbl_order');
        if(!empty($patient_id))
        {
            $this->db->where('patient_id', $patient_id);
        }
        $this->db->where('order_id', $order_id);
        $query = $this->db->get();
        return $query->row() ;
    }
    public function gettotalBreakfastOrderQty($patient_id, $order_id)
    {
        $this->db->select('SUM(qty) as qty');
        $this->db->from('tbl_breakfast_order');
        if(!empty($patient_id))
        {
            $this->db->where('patient_id', $patient_id);
        }
        $this->db->where('order_id', $order_id);
        $query = $this->db->get();
        return $query->row() ;
    }
}
?>
