<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Cron extends MY_Controller{
	function __construct(){
		parent::__construct();
		if(!empty(MODULE_NAME)){
			$this->load->model('common_model');
		}
	}
	
	/* State List by Country ID */
	public function index(){
		$c_date = date('Y-m-d');
		$check_macros = $this->common_model->getData('tbl_patient_macro', array('cron_date'=>$c_date), 'multi',NULL,NULL,NULL,'patient_id');
		if(!empty($check_macros))
		{
			foreach ($check_macros as $c_res) 
			{
				$check_order_res = $this->common_model->getData('tbl_order', array('patient_id'=>$c_res->patient_id), 'single');
				if(!empty($check_order_res))
				{
					$check_order_date_res = $this->common_model->getData('tbl_order', array('patient_id'=>$c_res->patient_id,'cron_date'=>$c_res->cron_date), 'single');
					if(empty($check_order_date_res))
					{
						/*mail send krne ka code khai*/
						echo "a";die;
						$patient_res = $this->common_model->getData('tbl_user', array('user_id'=>$c_res->patient_id), 'single');
						$loginUrl  = base_url();
						$credential_msg  = '';
						$credential_msg .= '<html><body bgcolor="#f6f8f1" style="min-width: 100% !important;color:#111 ; margin: 0; padding: 0;">';
						$credential_msg .= '<p><b>Dear  ' .$patient_res->user_fname.' '.$patient_res->user_lname.'</b></p>';
						/*$credential_msg .= '<p>We have recevied an order of client ' .$patient_res->user_fname.' '.$patient_res->user_lname.' mobile number '.$patient_res->user_mobile_no.', With the quantity 0f ' .$post['total_qty'].' Quantity. Please login to '.$loginUrl.' to see in details.</p>';*/
						$credential_msg .= '<p><b>Thanks & Regards</b></p>';
						$credential_msg .= '</body></html>';
				       	$subject = "Order Notification";

			       		$this->send_mail($patient_res->user_email, $subject, $credential_msg);
					}
				}
				else
				{
					echo "c";die;
					$patient_res = $this->common_model->getData('tbl_user', array('user_id'=>$c_res->patient_id), 'single');
						$loginUrl  = base_url();
						$credential_msg  = '';
					$credential_msg .= '<html><body bgcolor="#f6f8f1" style="min-width: 100% !important;color:#111 ; margin: 0; padding: 0;">';
					$credential_msg .= '<p><b>Dear  ' .$patient_res->user_fname.' '.$patient_res->user_lname.'</b></p>';
					$credential_msg .= '<p><b>Thanks & Regards</b></p>';
					$credential_msg .= '</body></html>';
			       	$subject = "Order Notification";
			       	$this->send_mail($patient_res->user_email, $subject, $credential_msg);
				}
			}
		}
	}
}
?>