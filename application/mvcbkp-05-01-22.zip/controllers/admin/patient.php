<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Patient extends MY_Controller{
	function __construct(){
		parent::__construct();
		if(!empty(MODULE_NAME)){
			$this->load->model(MODULE_NAME.'patient_model');
		}
	}
	
	/*	Validation Rules */
	protected $validation_rules = array(
        'userAdd' => array(
            array(
                'field' => 'user_fname',
                'label' => 'First Name',
                'rules' => 'trim|required|callback_alpha_dash_space'
            ),
            array(
                'field' => 'user_lname',
                'label' => 'Last Name',
                'rules' => 'trim|required|callback_alpha_dash_space'
            ),
            array(
                'field' => 'user_mobile_no',
                'label' => 'Phone Number',
                'rules' => 'trim|required'
            ), 
			array(
                'field' => 'user_email',
                'label' => 'Email',
                'rules' => 'trim|required|is_unique[tbl_user.user_email]|valid_email'
            ),
            array(
                'field' => 'user_name',
                'label' => 'User Name',
                'rules' => 'trim|required|is_unique[tbl_user.user_name]|is_unique[com_user_login_tbl.user_name]'
            )
        ),
		'patientUpdate' => array(
            array(
                'field' => 'user_fname',
                'label' => 'First Name',
                'rules' => 'trim|required|callback_alpha_dash_space'
            ),
            array(
                'field' => 'user_lname',
                'label' => 'Last Name',
                'rules' => 'trim|required|callback_alpha_dash_space'
            ),
            array(
                'field' => 'user_mobile_no',
                'label' => 'Phone Number',
                'rules' => 'trim|required'
            )
        )
    );

	public function index(){
		if($this->checkViewPermission()){			
			$this->data['user_res'] = $this->patient_model->getAllUserList();		
			$this->show_view(MODULE_NAME.'patient/patient_view', $this->data);
		}
		else{	
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
    }

    public function loadUserListData(){
    	$user_list = $this->patient_model->getAllUserList();
    	$data = array();
        $no = $_POST['start'];
        foreach ($user_list as $u_res){
        	$check_patient_macro = $this->common_model->getData('tbl_patient_macro', array('patient_id'=>$u_res->user_id), 'single');
        	$check_patient_macro_history = $this->common_model->getData(' tbl_patient_macro_history', array('patient_id'=>$u_res->user_id), 'single');
			$no++;
			$row   = array();
			$row[] = $no;
			if(!empty($u_res->user_profile_img)){
				$row[] = '<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)"><img width="50px"  onclick ="getFullSizePic(this.src)" src="'.base_url().''.$u_res->user_profile_img.'"></a>';
			}	
			else{
				$row[] = '<a data-toggle="modal" data-target="#myModal" href="javascript:void(0)"><img width="50px"  onclick ="getFullSizePic(this.src)" src="'.base_url().'webroot/upload/admin/users/user.png"></a>';
			}
			$row[] = $u_res->user_fname.' '.$u_res->user_lname;
			$row[] = $u_res->user_email;
			$row[] = $u_res->user_mobile_no;
			$row[] = viewStatus($u_res->user_status);
			
	 		$btn2 = '';
	 		if($this->checkViewPermission()){
	 			if(!empty($check_patient_macro_history))
	 			{
	 				$btn2 .= '<a class="btn btn-warning btn-sm" href="'.base_url().''.MODULE_NAME.'patient/patientMacroHistory/'.$u_res->user_id.'" title="Macro History"><i class="fa fa-eye fa-1x "></i></a>&nbsp;&nbsp;';
	 			}
	 			else
	 			{
	 				$btn2 .= '';
	 			}
	 		}
	 		$row[] = $btn2;
	 		$btn = '';
	 		if($this->checkViewPermission()){
	 			$btn .= '<a class="btn btn-success btn-sm" href="'.base_url().''.MODULE_NAME.'patient/patientView/'.$u_res->user_id.'" title="View"><i class="fa fa-eye fa-1x "></i></a>&nbsp;&nbsp;';
	 			$btn .= '<a class="btn btn-info btn-sm" href="'.base_url().''.MODULE_NAME.'patient/updatePatient/'.$u_res->user_id.'" title="edit"><i class="fa fa-edit fa-1x "></i></a>&nbsp;&nbsp;';
	 		}
	 		$row[] = $btn;
            $data[] = $row;
        }
        $output = array(
			"draw" => $_POST['draw'],
			"recordsTotal" => count($user_list),
			"recordsFiltered" => $this->patient_model->count_filtered(),
			"data" => $data,
		);
       	echo json_encode($output);
    }


	public function patientMacroHistory(){
		if($this->checkViewPermission()){			
			$user_id = $this->uri->segment(4);
			$edit_user = $this->common_model->getData('tbl_user', array('user_id'=>$user_id), 'single');
			if(!empty($edit_user))
			{
				$this->data['edit_user'] = $edit_user;
				$this->data['patient_id'] = $user_id;
				$this->show_view(MODULE_NAME.'patient/patient_macro_history', $this->data);
			}
			else
			{
				redirect(base_url().MODULE_NAME.'patient');
			}
		}
		else{	
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
	}

	public function patientView(){
		if($this->checkViewPermission()){			
			$user_id = $this->uri->segment(4);
			$edit_user = $this->patient_model->editUser($user_id);
			if(!empty($edit_user)){
				$this->data['edit_user'] = $edit_user;
				$this->data['country_list'] = $this->common_model->getAllCountry();
				$this->data['patient_id'] = $user_id;
				$this->show_view(MODULE_NAME.'patient/patient_full_view', $this->data);
			}
			else{
				redirect(base_url().MODULE_NAME.'patient');
			}
		}
		else{	
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
	}
	public function updatePatient(){
    	$user_id = $this->uri->segment(4);
		if($user_id){
			if($this->checkEditPermission()){
				if (isset($_POST['Submit']) && $_POST['Submit'] == "Edit"){
					$this->form_validation->set_rules($this->validation_rules['patientUpdate']);
					$post['user_email'] = $this->input->post('user_email');			
					$res = $this->common_model->checkUniqueValue('tbl_user', 'user_email', $post['user_email'], 'user_id', $user_id);
					if($res){
						$this->form_validation->set_rules('user_email','User Email','trim|xss_clean|required|is_unique[tbl_user.user_email]|valid_email');
					}
					if($this->form_validation->run()){
						$post['role_id'] = '4';
						$post['user_fname'] = $this->input->post('user_fname');
						$post['user_lname'] = $this->input->post('user_lname');
						$post['user_mobile_no'] = $this->input->post('user_mobile_no');
						
						$post['user_address'] = $this->input->post('user_address');
						if(!empty($post['user_address']))
                        {
                            $address_data = $this->get_latlong_by_address($post['user_address']);
                           if(!empty($address_data))
                           {
                               $post['user_latitude'] = $address_data['latitude'];
                               $post['user_longitude'] = $address_data['longitude'];
                           } 


                           $address_tbl_res = $this->common_model->getData('tbl_address', array('profile_address'=>1,'user_id'=>$user_id), 'single');
                           if(!empty($address_tbl_res))
                           {
                           		$post_adddr['user_address'] = $post['user_address'];
                           		$this->common_model->updateData('tbl_address', array('user_id'=>$user_id, 'profile_address'=>1),$post_adddr);
                           }
                        }
						$post['user_dob'] = $this->input->post('user_dob');
						$post['user_status'] = $this->input->post('user_status');						
						$post['email_reminder'] = $this->input->post('email_reminder');						
						$post['text_reminder'] = $this->input->post('text_reminder');						
						$post['user_all_level'] = $this->data['session']->user_all_level.','.$this->data['session']->user_id;
						$post['user_updated_date'] = date('Y-m-d');
						if($_FILES["user_profile_img"]["name"]){
	                       $user_profile_img = 'user_profile_img';
	                       $fieldName = "user_profile_img";
	                       $Path = 'webroot/upload/admin/users/profile';
	                       $user_profile_img = $this->ImageUpload($_FILES["user_profile_img"]["name"], $user_profile_img, $Path, $fieldName);
	                       $post['user_profile_img'] = $Path.'/'.$user_profile_img;
	                   	}
                        $n_post = $this->xssCleanValidate($post);
						$this->patient_model->updateUser($n_post,$user_id);       
	                   	$msg = 'Patient updated successfully!!';					
						$this->session->set_flashdata('message', '<section><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
						redirect(base_url().MODULE_NAME.'patient');
					}
					else{
						$edit_user = $this->patient_model->editUser($user_id);
						if(!empty($edit_user)){
							$this->data['edit_user'] = $edit_user;
							$this->data['patient_id'] = $user_id;
							$this->show_view(MODULE_NAME.'patient/patient_edit', $this->data);
						}
						else{
							redirect(base_url().MODULE_NAME.'patient/docpatientView/'.$doctor_id);
						}
					}
				}
				else{
					$edit_user = $this->patient_model->editUser($user_id);
					if(!empty($edit_user)){
						$this->data['edit_user'] 	= $edit_user;
						$this->data['patient_id'] 	= $user_id;
						
						$this->show_view(MODULE_NAME.'patient/patient_edit', $this->data);
					}
					else{
						redirect(base_url().MODULE_NAME.'patient/docpatientView/'.$doctor_id);
					}
				}
			}
			else{	
				redirect( base_url().MODULE_NAME.'dashboard/error/1');
			}
		}
    }
}
?>