<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class Dashboard extends MY_Controller{
	function __construct(){
		parent::__construct();
		if(!empty(MODULE_NAME)){
		   $this->load->model(MODULE_NAME.'dashboard_model');
		}
	}
	public function SendSmsApi()
	{
		$message = "PE ID 1201162434215777190 Trade Name - Octavian InfoTech LLP Dear rahul Patidar, your username is rahul and password is 123123. Dear rahul, your fees for feb is pending with amount 10000.";
		$password = 'Octa@0408@';
		$peid = '1201162434215777190';
		$dlttemplateid = '1207162468287849794';
		$curl = curl_init();
		$postData = array();
		curl_setopt_array($curl, array(
		  CURLOPT_URL => 'http://sms.octavianinfotech.com/api/mt/SendSMS?user=octavianinfotech&password='.$password.'&senderid=octavn&channel=Trans&DCS=0&flashsms=0&number=8959606470&text='.$message.'&route=2&peid='.$peid.'&dlttemplateid='.$dlttemplateid.'',
		  CURLOPT_RETURNTRANSFER => true,
		  CURLOPT_ENCODING => "",
		  CURLOPT_MAXREDIRS => 10,
		  CURLOPT_TIMEOUT => 30,
		  CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		  CURLOPT_CUSTOMREQUEST => "POST",
		  CURLOPT_POSTFIELDS => json_encode($postData),
		  CURLOPT_HTTPHEADER => array(
		    "Cache-Control: no-cache",
		    "Content-Type: application/json"
		  ),
		));

		$response = curl_exec($curl);
		$err = curl_error($curl);

		curl_close($curl);

		if ($err) {
		  echo "cURL Error #:" . $err;
		} else {
		  echo $response;
		}
	}

	function distance($latitude1, $longitude1, $latitude2, $longitude2) 
	{		
		/*echo $latitude1.'---'.$longitude1.'---'.$latitude2.'---'.$longitude2;die;*/
		$unit = 'miles';
 		$theta = $longitude1 - $longitude2; 
		$distance = (sin(deg2rad($latitude1)) * sin(deg2rad($latitude2))) + (cos(deg2rad($latitude1)) * cos(deg2rad($latitude2)) * cos(deg2rad($theta))); 
		$distance = acos($distance); 
		$distance = rad2deg($distance); 
		$miles = $distance * 60 * 1.1515; 
		/*$distance = $distance * 1.609344;*/ 
		return (round($miles,2)); 
		}
    public function index(){
    	/*$this->SendSmsApi();
	die;*/	
     	$role_id = $this->data['session']->role_id;
     	if($role_id == '2')
     	{
     		$this->chefDashboard();
     	}
     	else
     	{
	     	$doctor_id = $this->data['session']->doctor_id;
	     	if($doctor_id != '0')
	     	{
	     		$this->doctorPatient();
	     	}
	     	else
	     	{
	     		$this->selfPatient();
	     	}
     	}
	}

	public function chefDashboard(){
     	if($this->checkAddPermission())
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "search")
			{
				$start_date 	= $this->input->post('start_date');
				$end_date 		= $this->input->post('end_date');
			}
			else
			{
				$start_date 	= '';
				$end_date 		= '';
			}
			$this->data['start_date'] 	= $start_date;
			$this->data['end_date'] 	= $end_date;
			$this->show_view(MODULE_NAME.'chef_dashboard', $this->data);
		}
		else
		{
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
	}
	public function doctorPatient(){
    	/*$this->SendSmsApi();
	die;*/	
     	if($this->checkAddPermission())
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "Add")
			{
				$patient_id = $this->data['session']->user_id;
				$patient_res = $this->common_model->getData('tbl_user', array('user_id'=>$patient_id), 'single');
				if(!empty($patient_res))
				{
					$chef_res = $this->common_model->getData('tbl_user', array('user_id'=>'2'), 'single');
					if(!empty($chef_res))
					{
						$lat1 = $chef_res->user_latitude;
						$lon1 = $chef_res->user_longitude;
						$lat2 = $patient_res->user_latitude;
						$lon2 = $patient_res->user_longitude; 
						$distanc_res = $this->distance($lat1, $lon1, $lat2, $lon2);
						if(!empty($distanc_res))
						{
							$post_f['total_distance']  = round($distanc_res);
							$check_distance = $this->dashboard_model->checkDistanceRange($post_f['total_distance']);
							if(!empty($check_distance))
							{
								$post_f['distance_charge'] =  $check_distance->distance_amount;
							}
						}
						$extra_delivery_res = $this->common_model->getData('tbl_global_setting', NULL, 'single');
						if(!empty($extra_delivery_res))
						{
							if($extra_delivery_res->deliver_status == 'Off')
							{
								$post_f['extra_delivery_charge'] =  $extra_delivery_res->deliver_charge;
							}
							else
							{
								$post_f['extra_delivery_charge'] =  '0';
							}
						}

						if(!empty($extra_delivery_res))
						{
							if($extra_delivery_res->order_status == 'Open')
							{
								/*$current_date_time = date('2021-09-16 12:22');*/
								$current_date_time = date('Y-m-d H:i');
								$closeing_date  = $extra_delivery_res->closeing_date;
								$deadline_date  = $extra_delivery_res->deadline_date;
								if($current_date_time <= $closeing_date)
								{
									$post_f['late_charge'] =  '0';
								}
								else
								{
									/*if($current_date_time <= $deadline_date)
									{
										echo "cc";
									}
									else
									{
										echo "DD";
									}*/
									$post_f['late_charge'] =  $extra_delivery_res->late_charge;
									/*Chef Send to sms with multipale no*/
									$no_of_phone_no = $this->common_model->getData('tbl_phone_no', array('user_id'=>$chef_res->user_id), 'multi');
									if(!empty($no_of_phone_no))
									{
										foreach ($no_of_phone_no as $ph_res) 
										{
											/*SEND SMS API CODE*/
										}
									}
								}
							}
						}
					}
				}
				/*echo "<pre>";
				print_r($_POST);die;*/
				$product_id 	= $this->input->post('product_id');
				$macro_id 		= $this->input->post('macro_id');
				$macro_value_id = $this->input->post('macro_value_id');
				if(!empty($product_id)){
					for ($i=0; $i<count($product_id); $i++){
						if(!empty($product_id[$i])){
							$qty  = $this->input->post('qty');
							$product_res = $this->common_model->getData('tbl_product', array('product_id'=>$product_id[$i]), 'single');
							$post_f['product_price']  	= $product_res->product_price;

							$post_f['total_product_price']  = $macro_value_id[$i] * $post_f['product_price'];


							$post_f['product_id']  		= $product_id[$i];
							$post_f['macro_id']  		= $macro_id[$i];
							$post_f['macro_value_id']  	= $macro_value_id[$i];
							$post_f['qty']  			= $qty[$i];
							$post_f['patient_id']  		= $this->data['session']->user_id;

							$post_f['cart_created_date'] = date('Y-m-d');
							$post_f['cart_updated_date'] = date('Y-m-d');
							if($post_f['qty'] != 0)
							{
								$cart_check = $this->common_model->getData('tbl_cart', NULL, 'single', NULL, 'cart_id DESC');
								if(!empty($cart_check))
								{
									$post_f['unique_no'] = $cart_check->unique_no + 1;
								}
								else
								{
									$post_f['unique_no'] = 1;
								}
							}
							$post_f['note'] = $this->input->post('note');
							$nnn_post = $this->xssCleanValidate($post_f);
							$this->common_model->addData('tbl_cart', $nnn_post);
						}
					}	
				}
				/*breakfast*/
				$bre_post['qty'] = $this->input->post('break_fast_qty');
				if(!empty($bre_post['qty']))
				{
					$bre_post['breakfast_id_1'] = $this->input->post('breakfast_id_1');
					$bre_post['breakfast_qty_1'] = $this->input->post('breakfast_value_1');
					$bre_post['breakfast_product_id_1'] = $this->input->post('breakfast_product_id_1');
					$bre_post['breakfast_id_2'] = $this->input->post('breakfast_id_2');
					$bre_post['breakfast_qty_2'] = $this->input->post('breakfast_value_2');
					$bre_post['breakfast_product_id_2'] = $this->input->post('breakfast_product_id_2');
					$bre_post['patient_id'] = $patient_id;
					$bre_post['breakfast_cart_create_date'] = date('Y-m-d');

					$product_res1 = $this->common_model->getData('tbl_product', array('product_id'=>$bre_post['breakfast_product_id_1']), 'single');
					$product_price1  	= $product_res1->product_price;

					$product_res2 = $this->common_model->getData('tbl_product', array('product_id'=>$bre_post['breakfast_product_id_2']), 'single');
					$product_price2  	= $product_res2->product_price;

					$product_price = $bre_post['breakfast_qty_1'] * $product_price1 + $bre_post['breakfast_qty_2'] * $product_price2;
					$bre_post['breakfast_price'] = $product_price * $bre_post['qty'];
					$this->common_model->addData('tbl_breakfast_cart', $bre_post);
				}
				$msg = 'Cart added successfully!';	
					$this->session->set_flashdata('message', '<section><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(MODULE_NAME.'cart');	
			}
			else
			{
				$this->show_view(MODULE_NAME.'dashboard', $this->data);
			}
		}
		else
		{
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
	}

	public function selfPatient(){	
     	if($this->checkAddPermission())
		{
			if (isset($_POST['Submit']) && $_POST['Submit'] == "Add")
			{
				$patient_id = $this->data['session']->user_id;
				$patient_res = $this->common_model->getData('tbl_user', array('user_id'=>$patient_id), 'single');
				if(!empty($patient_res))
				{
					$chef_res = $this->common_model->getData('tbl_user', array('user_id'=>'2'), 'single');
					if(!empty($chef_res))
					{
						$lat1 = $chef_res->user_latitude;
						$lon1 = $chef_res->user_longitude;
						$lat2 = $patient_res->user_latitude;
						$lon2 = $patient_res->user_longitude; 
						$distanc_res = $this->distance($lat1, $lon1, $lat2, $lon2);
						if(!empty($distanc_res))
						{
							$post_f['total_distance']  = round($distanc_res);
							$check_distance = $this->dashboard_model->checkDistanceRange($post_f['total_distance']);
							if(!empty($check_distance))
							{
								$post_f['distance_charge'] =  $check_distance->distance_amount;
							}
						}
						$extra_delivery_res = $this->common_model->getData('tbl_global_setting', NULL, 'single');
						if(!empty($extra_delivery_res))
						{
							if($extra_delivery_res->deliver_status == 'Off')
							{
								$post_f['extra_delivery_charge'] =  $extra_delivery_res->deliver_charge;
							}
							else
							{
								$post_f['extra_delivery_charge'] =  '0';
							}
						}
						if(!empty($extra_delivery_res))
						{
							if($extra_delivery_res->order_status == 'Open')
							{
								/*$current_date_time = date('2021-09-16 12:22');*/
								$current_date_time = date('Y-m-d H:i');
								$closeing_date  = $extra_delivery_res->closeing_date;
								$deadline_date  = $extra_delivery_res->deadline_date;
								if($current_date_time <= $closeing_date)
								{
									$post_f['late_charge'] =  '0';
								}
								else
								{
									/*if($current_date_time <= $deadline_date)
									{
										echo "cc";
									}
									else
									{
										echo "DD";
									}*/
									$post_f['late_charge'] =  $extra_delivery_res->late_charge;
									$no_of_phone_no = $this->common_model->getData('tbl_phone_no', array('user_id'=>$chef_res->user_id), 'multi');
									if(!empty($no_of_phone_no))
									{
										foreach ($no_of_phone_no as $ph_res) 
										{
											/*SEND SMS API CODE*/
										}
									}
								}
							}
						}
					}
				}
				/*echo "<pre>";
				print_r($_POST);die;*/
				$product_id 	= $this->input->post('product_id');
				$macro_id 		= $this->input->post('macro_id');
				$macro_value_id = $this->input->post('macro_value_id');
				if(!empty($product_id)){
					for ($i=0; $i<count($product_id); $i++){
						if(!empty($product_id[$i])){
							$qty  = $this->input->post('qty');
							$product_res = $this->common_model->getData('tbl_product', array('product_id'=>$product_id[$i]), 'single');
							$post_f['product_price']  	= $product_res->product_price;

							$post_f['total_product_price']  = $macro_value_id[$i] * $post_f['product_price'];


							$post_f['product_id']  		= $product_id[$i];
							$post_f['macro_id']  		= $macro_id[$i];
							$post_f['macro_value_id']  	= $macro_value_id[$i];
							$post_f['qty']  			= $qty[$i];
							$post_f['patient_id']  		= $this->data['session']->user_id;

							$post_f['cart_created_date'] = date('Y-m-d');
							$post_f['cart_updated_date'] = date('Y-m-d');
							if($post_f['qty'] != 0)
							{
								$cart_check = $this->common_model->getData('tbl_cart', NULL, 'single', NULL, 'cart_id DESC');
								if(!empty($cart_check))
								{
									$post_f['unique_no'] = $cart_check->unique_no + 1;
								}
								else
								{
									$post_f['unique_no'] = 1;
								}

							}
							$post_f['note'] = $this->input->post('note');
							$nnn_post = $this->xssCleanValidate($post_f);
							$this->common_model->addData('tbl_cart', $nnn_post);
						}
					}	
				}
				/*breakfast*/
				$bre_post['qty'] = $this->input->post('break_fast_qty');
				if(!empty($bre_post['qty']))
				{
					$bre_post['breakfast_id_1'] = $this->input->post('breakfast_id_1');
					$bre_post['breakfast_qty_1'] = $this->input->post('breakfast_value_1');
					$bre_post['breakfast_product_id_1'] = $this->input->post('breakfast_product_id_1');
					$bre_post['breakfast_id_2'] = $this->input->post('breakfast_id_2');
					$bre_post['breakfast_qty_2'] = $this->input->post('breakfast_value_2');
					$bre_post['breakfast_product_id_2'] = $this->input->post('breakfast_product_id_2');
					$bre_post['patient_id'] = $patient_id;
					$bre_post['breakfast_cart_create_date'] = date('Y-m-d');

					$product_res1 = $this->common_model->getData('tbl_product', array('product_id'=>$bre_post['breakfast_product_id_1']), 'single');
					$product_price1  	= $product_res1->product_price;

					$product_res2 = $this->common_model->getData('tbl_product', array('product_id'=>$bre_post['breakfast_product_id_2']), 'single');
					$product_price2  	= $product_res2->product_price;

					$product_price = $bre_post['breakfast_qty_1'] * $product_price1 + $bre_post['breakfast_qty_2'] * $product_price2;
					$bre_post['breakfast_price'] = $product_price * $bre_post['qty'];
					$this->common_model->addData('tbl_breakfast_cart', $bre_post);
				}
				$msg = 'Cart added successfully!';	
					$this->session->set_flashdata('message', '<section><div class="col-xs-12"><div class="alert alert-success alert-dismissable"><i class="fa fa-check"></i><button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>'.$msg.'</div></div></section>');
					redirect(MODULE_NAME.'cart');	
			}
			else
			{
				$this->show_view(MODULE_NAME.'self_patient_dashboad', $this->data);
			}
		}
		else
		{
			redirect( base_url().MODULE_NAME.'dashboard/error/1');
		}
	}
	public function error(){	
		$value = $this->uri->segment(4);
		if($value == '1'){	
			$this->show_view(MODULE_NAME.'error/error_permission', $this->data);
		}		
    }
}
?>