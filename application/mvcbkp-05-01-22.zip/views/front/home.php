<style type="text/css">
	.person-info h5 {
    margin-bottom: 64px;
    color: #fb3d3d;
    font-size: 24px;
	}
	.dot{width: 200px;}
</style>
<style type="text/css">
.job_top_headBox {
    position: relative;
    padding: 15px;
    border: 1px solid #666;
}
.job_top_headBox h2 {
    font-size: 38px;
    margin-bottom: 20px;
    font-family: 'Playfair Display', serif;
    font-weight: bold;
    line-height: 38px;
}
.job_top_headBox h2 a {
    font-family: 'Playfair Display', serif;
    word-break: break-all;
}
.form_application_detail_vs {
    position: relative;
    border: 1px solid #666;
    margin-top: -1px;
}

.form_application_detail_vs .col-md-3 {
    border-left: 1px solid #666;
}
.form_application_detail_vs .col-md-3 {
    padding: 20px 50px;
}
.form_application_detail_vs .row {
    margin: 0;
}
.form_application_detail_vs h3 {
    color: #007e00;
    font-size: 28px;
    margin-bottom: 20px;
    font-family: 'Playfair Display', serif;
    font-weight: bold;
}
ul.form_application_detail_vs_uline {
    margin: 0;
    font-family: 'Playfair Display', serif;
    font-size: 20px;
    line-height: 22px;
}
ul.form_application_detail_vs_uline li {
    margin-bottom: 5px;
}
@media (max-width: 767px){
	.job_top_headBox h2 {
	    font-size: 26px;
	    margin-bottom: 18px;
	    line-height: 26px;
	}
	.form_application_detail_vs .col-md-3 {
	    padding: 30px 40px;
	}
	.form_application_detail_vs .col-md-3:last-child {
	    border-left: none;
	}
}
</style>
<?php
$global_setting_res = $this->common_model->getData('tbl_global_setting', NULL, 'single');
$order_status = (!empty($global_setting_res->order_status)) ? $global_setting_res->order_status : '';
$deadline_date = (!empty($global_setting_res->deadline_date)) ? $global_setting_res->deadline_date : '';
?>
<section class="contact-us section-space">
	<div class="container">
		<div class="row">
			<div class="col-lg-8 col-md-8 col-12">
				<div class="section-title style2 ">
					<div class="section-top">
						<h1><span>menu</span><b>Current Menu</b></h1>
						<h4>Lorem ipsum dolor sit amet, consectetursed do ei</h4>
					</div>
				</div>
			</div>
		</div>
		

		<div class="row">
			<div class="col-9">
				<div class="job_detail_content_vs">
					<div class="text-center job_top_headBox">
						<h2 style="color: #f0080f">Current Menu</h2>
					</div>
					<div class="form_application_detail_vs">
						<div class="row">
							<div class="col-md-3">
								<?php
								$category_res = $this->common_model->getData('tbl_category', array('category_status '=>1), 'multi');
								if(!empty($category_res))
								{
									foreach ($category_res as  $c_res) 
									{
										if($c_res->category_id == '1')
										{
											?>
											<h3 ><?php echo $c_res->category_name; ?></h3>
											<?php
											$product_res = $this->common_model->getData('tbl_product', array('product_status '=>1, 'category_id'=>1), 'multi');
											if(!empty($product_res))
											{
												foreach ($product_res as $p_res) 
												{
													?>
													<ul class="form_application_detail_vs_uline">
														<li><?php echo $p_res->product_name; ?></li>
													</ul>
													<?php

												}
											}
										}


									}
								}
								?>
							</div>
							<div class="col-md-3">
								<?php
								$category_res = $this->common_model->getData('tbl_category', array('category_status '=>1), 'multi');
								if(!empty($category_res))
								{
									foreach ($category_res as  $c_res) 
									{
										if($c_res->category_id == '2')
										{
											?>
											<h3 ><?php echo $c_res->category_name; ?></h3>
											<?php
											$product_res = $this->common_model->getData('tbl_product', array('product_status '=>1, 'category_id'=>2), 'multi');
											if(!empty($product_res))
											{
												foreach ($product_res as $p_res) 
												{
													?>
													<ul class="form_application_detail_vs_uline">
														<li><?php echo $p_res->product_name; ?></li>
													</ul>
													<?php

												}
											}
										}


									}
								}
								?>
							</div>
							<div class="col-md-3">
								<?php
								$category_res = $this->common_model->getData('tbl_category', array('category_status '=>1), 'multi');
								if(!empty($category_res))
								{
									foreach ($category_res as  $c_res) 
									{
										if($c_res->category_id == '3')
										{
											?>
											<h3 ><?php echo $c_res->category_name; ?></h3>
											<?php
											$product_res = $this->common_model->getData('tbl_product', array('product_status '=>1, 'category_id'=>3), 'multi');
											if(!empty($product_res))
											{
												foreach ($product_res as $p_res) 
												{
													?>
													<ul class="form_application_detail_vs_uline">
														<li><?php echo $p_res->product_name; ?></li>
													</ul>
													<?php

												}
											}
										}


									}
								}
								?>
							</div>
							<div class="col-md-3">
								<?php
								$category_res = $this->common_model->getData('tbl_category', array('category_status '=>1), 'multi');
								if(!empty($category_res))
								{
									foreach ($category_res as  $c_res) 
									{
										if($c_res->category_id == '4')
										{
											?>
											<h3 ><?php echo $c_res->category_name; ?></h3>
											<?php
											$product_res = $this->common_model->getData('tbl_product', array('product_status '=>1, 'category_id'=>4), 'multi');
											if(!empty($product_res))
											{
												foreach ($product_res as $p_res) 
												{
													?>
													<ul class="form_application_detail_vs_uline">
														<li><?php echo $p_res->product_name; ?></li>
													</ul>
													<?php

												}
											}
										}


									}
								}
								?>
							</div>

						</div>
					</div>
				</div>
			</div>
			<div class="col-md-3">
				<div class="container">
					<div class="row justify-content-center">
						<div class="col-lg-12 col-md-12 col-12">
							<div class="section-title style2 ">
								<div class="section-top">
									<h1><span>Countdown Timer</span>
								</div>
							</div>
						</div>
					</div>
					<div class="row justify-content-center">
						<div class="col-12 col-lg-12 col-md-6 mb-30">
							<div class="card border-0 has-shadow h-100 dot">
								<div class="card-header border-0 text-center" style="border-radius: 111%;background-color: <?PHP echo THEME_COLOR; ?>;">
									
									<div class="person-info">
										<h5><p style="text-align: center;font-size: 20px;margin-top: 69px;" id="demo"></p></h5>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		
	</div>
</section>
<script>
	/*var deadline_date = '2021-11-11 22:00:00';*/
	var deadline_date = '<?php echo $deadline_date; ?>';
// Set the date we're counting down to
var countDownDate = new Date(deadline_date).getTime();
// Update the count down every 1 second
var x = setInterval(function() {

  // Get today's date and time
  var now = new Date().getTime();
    
  // Find the distance between now and the count down date
  var distance = countDownDate - now;
    
  // Time calculations for days, hours, minutes and seconds
  var days = Math.floor(distance / (1000 * 60 * 60 * 24));
  var hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  var minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  var seconds = Math.floor((distance % (1000 * 60)) / 1000);
    
  // Output the result in an element with id="demo"
  document.getElementById("demo").innerHTML = days + "d " + hours + "h "
  + minutes + "m " + seconds + "s ";
    
  // If the count down is over, write some text 
  if (distance < 0) {
    clearInterval(x);
    document.getElementById("demo").innerHTML = "EXPIRED";
  }
}, 1000);
</script>