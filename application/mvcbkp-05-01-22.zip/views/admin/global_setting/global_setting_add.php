<aside class="right-side">
    <section class="content-header">
        <h1>Global Setting</h1>
        <ol class="breadcrumb">
            <li><a href="<?php echo base_url().MODULE_NAME;?>dashboard"><i class="fa fa-dashboard"></i>Home</a></li>
            <li><a href="<?php echo base_url().MODULE_NAME;?>globalSetting">Global Setting</a></li>
            <li class="active">Global Setting Add</li>
        </ol>
    </section>
    <section class="content">       
        <div class="box box-success">
            <div class="box-header">
                <div class="tab-content">
                    <div class="pull-left">
                        <!-- <h3 class="box-title">Create Global Setting</h3> -->
                    </div>
                    <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <?php  $csrf = array( 'name' => $this->security->get_csrf_token_name(), 'hash' => $this->security->get_csrf_hash() ); ?>
                        <input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" />
                        <input type="hidden" name="gs_id" value="<?= (!empty($gs_setting)) ? $gs_setting->gs_id : ''; ?>">
                        <div class="pull-right">
                            <button class="btn btn-success btn-sm" type="submit" name="Submit" value="<?= (!empty($gs_setting)) ? 'Edit' : 'Add' ?>" >Submit</button>
                        </div>
                        <div class="box-body">
                            <div>
                                <div id="msg_div">
                                    <?php echo $this->session->flashdata('message');?>
                                </div>
                            </div> <br><br>
                            <div class="row">
                                <div class="col-md-12">
                                    <div class="panel panel-info" style="box-shadow: none; background-color: #dfe7f1;">
                                        <div class="panel-heading" style="background-color: #bad59c; color: #22255a;">Create Global Setting
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <div class="input text">
                                                        <label>Delivery Status</label>
                                                        <select class="form-control" name="deliver_status" id="deliver_status" onchange="showDeliveryAmount(this.value)">
                                                                <option value="0">Select Delivery Status</option>
                                                                <option <?php echo (!empty($gs_setting) && $gs_setting->deliver_status == 'On') ? 'selected' : '' ;?> value="On">On</option>
                                                                <option <?php echo (!empty($gs_setting) && $gs_setting->deliver_status == 'Off') ? 'selected' : '' ;?> value="Off">Off</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div id="show_div" style="
                                                <?php
                                                if(!empty($gs_setting))
                                                {
                                                    if($gs_setting->deliver_status =='On' || $gs_setting->deliver_status == ''){ echo "display: none"; };
                                                }
                                                else
                                                {
                                                    echo "display: none";
                                                }
                                                ?>
                                                " class="form-group col-md-8">
                                                    <div class="input text">
                                                        <label>Enter Delivery Amount</label>
                                                        <input type="text" name="deliver_charge" id="deliver_charge" class="form-control" value="<?php echo (!empty($gs_setting)) ? $gs_setting->deliver_charge : ''; ?>">
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <div class="input text">
                                                        <label>Enter Tax (Percentage) <span class="text-danger">*</span></label>
                                                        <div class='input-group'>
                                                            <input required data-validation="number" data-validation-allowing="float" min="0" type="text" name="tax" id="tax" class="form-control" value="<?php echo (!empty($gs_setting)) ? $gs_setting->tax : ''; ?>">
                                                            <span class="input-group-addon">
                                                                %
                                                            </span>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-8">
                                                    <div class="input text">
                                                        <label>Enter Special Delivery Amount<span class="text-danger">*</span></label>
                                                        <input required data-validation="custom" data-validation-regexp="^([0-9]+)$" type="text" name="special_delivery_charge" id="special_delivery_charge" class="form-control" value="<?php echo (!empty($gs_setting)) ? $gs_setting->special_delivery_charge : ''; ?>">
                                                    </div>
                                                </div>
                                            </div> 
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <div class="input text">
                                                        <label>Expiry Date<span class="text-danger">*</span></label>
                                                         <div class='input-group'>
                                                           <input autocomplete="off" data-validation="date" type="text" name="expire_date" id="expire_date" class="form-control current_date_val" value="<?php echo (!empty($gs_setting)) ? $gs_setting->expire_date : ''; ?>">
                                                           <span class="input-group-addon">
                                                               <span class="glyphicon glyphicon-calendar"></span>
                                                           </span>
                                                       </div>
                                                        <?php echo form_error('expire_date  ','<span class="text-danger">','</span>'); ?>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label>Set Theme Color<span class="text-danger">*</span></label>
                                                    <input type="color" name="theme_color" id="theme_color" class="form-control" value="<?php echo (!empty($gs_setting)) ? $gs_setting->theme_color : ''; ?>">
                                                </div>
                                            </div>
                                            <div class="row">
                                                <div class="form-group col-md-4">
                                                    <div class="input text">
                                                        <label>Order Status</label>
                                                        <select class="form-control" name="order_status" id="order_status" onchange="showOrderAmount(this.value)">
                                                                <option value="0">Select Order Status</option>
                                                                <option <?php echo (!empty($gs_setting) && $gs_setting->order_status == 'Open') ? 'selected' : '' ;?> value="Open">Open</option>
                                                                <option <?php echo (!empty($gs_setting) && $gs_setting->order_status == 'Close') ? 'selected' : '' ;?> value="Close">Close</option>
                                                        </select>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="row" id="show_late_div" style="
                                                <?php
                                                if(!empty($gs_setting))
                                                {
                                                    if($gs_setting->order_status =='Close' || $gs_setting->order_status == ''){ echo "display: none"; };
                                                }
                                                else
                                                {
                                                    echo "display: none";
                                                }
                                                ?>
                                                ">
                                                <div class="form-group col-md-4">
                                                    <label>Closing Date/Time</label>
                                                    <div class="input-group date">
                                                        <input autocomplete="off" type="text" class="form-control datetimepicker1" name="closeing_date" id="closeing_date" value="<?php echo (!empty($gs_setting)) ? $gs_setting->closeing_date : ''; ?>" required="required">
                                                        <span class="input-group-addon">
                                                           <span class="glyphicon glyphicon-calendar"></span>
                                                        </span>
                                                    </div>
                                                   <span class="text-danger"></span>
                                                </div>
                                                <div class='form-group col-md-4' id="end_date_div">
                                                    <label>Deadline Date/Time<span class="text-danger">*</span></label>
                                                    <div class="input-group date">
                                                        <input autocomplete="off" type="text" class="form-control datetimepicker1" name="deadline_date" id="deadline_date" value="<?php echo (!empty($gs_setting)) ? $gs_setting->deadline_date : ''; ?>" >
                                                        <span class="input-group-addon">
                                                           <span class="glyphicon glyphicon-calendar"></span>
                                                        </span>
                                                    </div>
                                                </div>
                                                <div class="form-group col-md-4">
                                                    <label>Enter Late Charge<span class="text-danger">*</span></label>
                                                    <div class='input-group'>
                                                        <span class="input-group-addon">
                                                            $
                                                        </span>
                                                        <input required data-validation="custom" data-validation-regexp="^([0-9]+)$" type="text" name="late_charge" id="late_charge" class="form-control" value="<?php echo (!empty($gs_setting)) ? $gs_setting->late_charge : ''; ?>">
                                                        </div>
                                                </div>
                                            </div>
                                            <div class="row">
	                                            <div class="form-group col-md-12">
	                                                <div class="input text">
	                                                    <label>Mail Reminder Body</label>
	                                                    <textarea rows="4" name="pending_order_mail_body" id="pending_order_mail_body" class="form-control"><?php echo (!empty($gs_setting)) ? $gs_setting->pending_order_mail_body : ''; ?></textarea>
	                                                </div>
	                                            </div>
	                                        </div> 
                                            <div class="row">
                                                <div class="form-group col-md-12">
                                                    <div class="input text">
                                                        <label>Sms Reminder Body</label>
                                                        <textarea rows="4" name="sms_Reminder_body" id="sms_Reminder_body" class="form-control"><?php echo (!empty($gs_setting)) ? $gs_setting->sms_Reminder_body : ''; ?></textarea>
                                                    </div>
                                                </div>
                                            </div>
                                        <div class="panel-heading" style="background-color: <?PHP echo THEME_COLOR; ?>; color: #22255a;">Distance Amount
                                        </div>
                                        <div class="panel-body">
                                            <div class="row">
                                                <div class="col-md-12">
                                                    <div class="table-responsive">
                                                    <table id="load_categorylist" class="table table-bordered table-striped">
                                                        <thead>
                                                            <tr class="label-primary1">
                                                                <th>S.No.</th>
                                                                <th>Distance Range</th>
                                                                <th>Distance Amount</th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <?php
                                                            $distance_res = $this->common_model->getData('tbl_distance', NULL, 'multi');
                                                            if(!empty($distance_res))
                                                            {
                                                                $i = 1;
                                                                foreach($distance_res as $res)
                                                                {
                                                                    ?>    
                                                                    <tr>
                                                                        <td><?php echo $i; ?></td>
                                                                        <?php
                                                                        if($res->distance_id != '5')
                                                                        {
                                                                            ?>
                                                                            <td><?php echo $res->distance_range_start.' -  '.$res->distance_range_end; ?></td>
                                                                            <?php
                                                                        }
                                                                        else
                                                                        {
                                                                            ?>
                                                                            <td><?php echo $res->distance_range_start.' -  '.'Above'; ?></td>
                                                                            <?php
                                                                        }
                                                                        ?>
                                                                        <td>
                                                                            <div class='input-group'>
                                                                                <span class="input-group-addon">
                                                                                    $
                                                                                </span>
                                                                                <input autocomplete="off" type="text" name="distance_amount_<?php echo $res->distance_id; ?>" class="form-control" value="<?php echo $res->distance_amount; ?>">
                                                                            </div>
                                                                        </td>
                                                                    </tr>
                                                                    <?php
                                                                    $i++;
                                                                }
                                                            }
                                                            else
                                                            {
                                                                ?>
                                                                <tr>
                                                                    <td colspan="12">No records found...</td>
                                                                </tr>
                                                                <?php
                                                            }
                                                            
                                                        ?>
                                                        </tbody>
                                                    </table>
                                                </div>
                                                </div>
                                            </div> 
                                        </div>

                                        <div class="row">
                                            <div class="form-group col-md-12">
                                                <div class="input text">
                                                    <label>PRIVACY POLICY</label>
                                                    <textarea rows="4" name="privacy_policy" id="privacy_policy" class="form-control tiny_textarea"><?php echo (!empty($gs_setting)) ? $gs_setting->privacy_policy : ''; ?></textarea>
                                                </div>
                                            </div>
                                        </div> 
                                        <div class="row">
                                            <div class="form-group col-md-12">
                                                <div class="input text">
                                                    <label>TERMS & CONDITIONS</label>
                                                    <textarea rows="4" name="term_n_condition" id="term_n_condition" class="form-control tiny_textarea"><?php echo (!empty($gs_setting)) ? $gs_setting->term_n_condition : ''; ?></textarea>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="box-footer">
                            <button class="btn btn-success btn-sm" type="submit" name="Submit" value="<?= (!empty($gs_setting)) ? 'Edit' : 'Add' ?>" >Submit</button>
                            <a class="btn btn-danger btn-sm" href="<?php echo base_url().MODULE_NAME;?>globalSetting">Cancel</a>
                        </div>
                    </form>
                </div>
            </div>
    </section>
</aside>
<div id="myModal" class="modal fade" role="dialog">
</div>
<link href="<?php echo base_url();?>webroot/css/bootstrap-datetimepicker.css" rel="stylesheet">
<link rel="stylesheet" type="text/css" media="screen" href="<?php echo base_url();?>webroot/css/bootstrap.min.css" />
<script src="<?php echo base_url(); ?>webroot/js/moment-with-locales.js"></script>
<script src="<?php echo base_url(); ?>webroot/js/bootstrap-datetimepicker.js"></script>
<script type="text/javascript">
    $(function () {
        $('body').on('focus', ".datetimepicker1", function(){
           $(this).datetimepicker({
               format: 'YYYY-MM-DD HH:ss',
               useCurrent: true
            });
        });

        $('.datetimepicker1').on('dp.change', function(){
            var from_date = $('.datetimepicker1').val();
            $('#end_date_div').html('<label>End Date<span class="text-danger">*</span></label><div class="input-group date"><input autocomplete="off" type="text" class="form-control datetimepicker1" name="deadline_date" id="deadline_date" value="" required="required"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span></div>');
            $("#deadline_date" ).datetimepicker({
                   format: 'YYYY-MM-DD HH:ss',
                   useCurrent: true,
                   minDate: new Date(from_date)
               });
           });
    });
    function showOrderAmount(str)
    {
        if(str == 'Open')
        {
            $('#show_late_div').show();
        }
        else if(str == 'Close')
        {
            $('#show_late_div').hide();
        }
        else
        {
            $('#show_late_div').hide();
        }
    }
    function showDeliveryAmount(str)
    {
        if(str == 'Off')
        {
            $('#show_div').show();
        }
        else if(str == 'On')
        {
            $('#show_div').hide();
        }
        else
        {
            $('#show_div').hide();
        }
    }
</script>
