<style type="text/css">
   .mx-60 {
            max-width: 60px;
        }

        .mx-120 {
            max-width: 120px;
        }

        .my-16{
            margin-top: 16px;
            margin-bottom: 16px;
        }

        .multiple-input{
            display: flex;
        }
        .multiple-input .form-control{
            max-width: 60px;
        }
</style>
<aside class="right-side">
   <section class="content-header">
      <?php
      if(!empty($role_id))
      {
        if($role_id == '4' && $patient_doctor_id =='0')
        {
            ?>
            <h1>Select Meal Macro</h1>
               <ol class="breadcrumb">
                  <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
                  <li class="active">Select Meal Macro</li>
               </ol>
            <?php
        }
        else
        {
         ?>
         <h1>Dashboard</h1>
            <ol class="breadcrumb">
               <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
               <li class="active">dashboard</li>
            </ol>
         <?php
        }
      }
      ?>
      <?php
      if(!empty($role_id))
      {
        if($role_id == '4' && $patient_doctor_id =='0')
        {
            ?>
            <section class="content">
              <div class="box box-success">
                 <div>
                   <div id="msg_div">
                       <?php echo $this->session->flashdata('message');?>
                   </div>
               </div>
                 <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                    <?php $csrf = array( 'name' => $this->security->get_csrf_token_name(), 'hash' => $this->security->get_csrf_hash() );?>
                    <!-- <input type="text" name="latitude" id="latitude">
                    <input type="text" name="longitude" id="longitude"> -->
                    <input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" /> 
                    <body style="padding: 50px 0;">
                      <?php
                        if(!empty($role_id))
                        {
                            if($role_id == '4' && $patient_doctor_id =='0')
                            {
                                ?>
                                <div class="container">
                                  <div class="row">
                                      <div class="col-md-12 col-lg-7">

                                          <div class="form-group">
                                              <label for="">Select Meal Macro </label>
                                              <div class="input-group multiple-input">
                                              </div>
                                          </div>
                                          <div class="table-responsive">
                                              <table class="table table-bordered">
                                                  <thead>
                                                      <tr>
                                                          <th>Quantity</th>
                                                          <?php
                                                              $macro_res = $this->common_model->getData('tbl_macro', array('macro_status'=>'1'), 'multi');
                                                                if(!empty($macro_res))
                                                                {
                                                                    foreach ($macro_res as $p_res) 
                                                                    {
                                                                       ?><th><?php echo $p_res->macro_name; ?></th><?php
                                                                    
                                                                    }
                                                                }
                                                             ?>
                                                      </tr>
                                                  </thead>

                                                  <tbody id="add_emp_dep_box_div">
                                                      <tr>
                                                          
                                                          <?php
                                                             if(!empty($macro_res))
                                                             {
                                                               foreach ($macro_res as $p_res) 
                                                               {
                                                                   
                                                                   $product_res = $this->common_model->getData('tbl_product', array('category_id'=>$p_res->macro_id), 'multi');
                                                                   ?>
                                                                   <?php
                                                                   if($p_res->macro_id == '1')
                                                                   {
                                                                    ?>
                                                                     <td>
                                                                        <input required min="0" type="number" name="qty[]" value="" placeholder="#" class="form-control mx-120">
                                                                        <input min="0" type="hidden" name="qty[]" value="0" placeholder="#" class="form-control mx-120">
                                                                        <input min="0" type="hidden" name="qty[]" value="0" placeholder="#" class="form-control mx-120">
                                                                    </td>
                                                                    <?php
                                                                   }
                                                                   ?>
                                                                   <td>
                                                          
                                                                          <div class="input-group">
                                                                            <input type="hidden" name="macro_id[]" value="<?php echo $p_res->macro_id; ?>" class="form-control" placeholder="#">
                                                                            <input required type="text" name="macro_value_id[]" value="" class="form-control" placeholder="#">
                                                                            <div class="input-group-addon">
                                                                                
                                                                                <select required style="height: 26px;" name="product_id[]" class="selectedDepartment">
                                                                                    <option value=""><?php echo $p_res->macro_name; ?></option>
                                                                                    <?php
                                                                                    if(!empty($product_res)){
                                                                                          foreach($product_res as $res){
                                                                                              ?>
                                                                                              <option value="<?php echo $res->product_id; ?>"><?php echo $res->product_name; ?></option>
                                                                                              <?php
                                                                                          }
                                                                                      }
                                                                                    ?>
                                                                                 </select>
                                                                            </div>
                                                                        </div>
                                                                      </td>
                                                                   <?php
                                                               }
                                                             }
                                                            ?>
                                                      </tr>
                                                  </tbody>
                                              </table>
                                          </div>
                                          <div class="my-16">
                                            <input type="hidden" name="no_of_emp_dep_box" id="no_of_emp_dep_box" value="1">
                                              <button type="button" id="add_emp_dep_box"  class="btn btn-default">Add Meal</button>
                                              <button type="button" id="remove_emp_dep_box" style="display: none;" class="btn btn-danger">Remove Meal</button>
                                              <button type="submit" name="Submit" value="Add" class="btn btn-primary">Checkout</button>
                                          </div>
                                      </div>
                                      <div class="col-md-12 col-lg-5">
                                        <div class="table-responsive">
                                            <table id="example_scroll" class="table table-condensed table-bordered">
                                                <thead>
                                                    <tr>
                                                        <th colspan="5">Standard Meals</th>
                                                    </tr>
                                                    <tr>
                                                        <!-- <th>#</th> -->
                                                        <th>Protein Serving</th>
                                                        <th>Carb Serving</th>
                                                        <th>Veg Serving</th>
                                                        <th>Price</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    <?php
                                                    $standard_meal_res = $this->common_model->getData(' tbl_standard_meal', array('meal_status'=>1), 'multi');
                                                    if(!empty($standard_meal_res))
                                                    {
                                                        foreach ($standard_meal_res as $s_res) 
                                                        {
                                                            ?>
                                                            <tr>
                                                                <!-- <td>
                                                                <input type="radio" name="meal_name" id="meal_<?php echo $s_res->meal_id; ?>" >
                                                                </td> -->
                                                                <td><?php echo $s_res->protien_serving; ?></td>
                                                                <td><?php echo $s_res->carb_serving; ?></td>
                                                                <td><?php echo $s_res->veg_serving; ?></td>
                                                                <td>$<?php echo $s_res->price; ?></td>
                                                            </tr>
                                                            <?php
                                                        }
                                                    }
                                                    ?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>

                                  </div>
                              </div>
                                <?php
                            }
                        }
                      ?>
                      

                  </body> 
                 </form>  
                 </div>  
           </section>
            <?php
        }
      }
      ?>
   </section>
</aside>
<script type="text/javascript">
  var order_Data = [];
   $(document).ready(function(){
        var langind_box = '1';
        var langind_box_n = parseInt(langind_box) + 1;
        $("#add_emp_dep_box").click(function (){
            $('#remove_emp_dep_box').show();
            var newTextBoxDiv = $(document.createElement('tr')).attr("id", 'rm_langing_box_div' + langind_box);
            newTextBoxDiv.after().html(`
                <?php
                if(!empty($macro_res))
                {
                foreach ($macro_res as $p_res) 
                {
                   
                   $product_res = $this->common_model->getData('tbl_product', array('category_id'=>$p_res->macro_id), 'multi');
                   ?>
                   <?php
                   if($p_res->macro_id == '1')
                   {
                    ?>
                     <td>
                        <input min="0" required type="number" name="qty[]" value="" placeholder="#" class="form-control mx-120">
                        <input min="0" type="hidden" name="qty[]" value="0" placeholder="#" class="form-control mx-120">
                        <input min="0" type="hidden" name="qty[]" value="0" placeholder="#" class="form-control mx-120">
                    </td>
                    <?php
                   }
                   ?>
                   <td>

                          <div class="input-group">
                            <input type="hidden" name="macro_id[]" value="<?php echo $p_res->macro_id; ?>" class="form-control" placeholder="#">
                            <input required type="text" name="macro_value_id[]" value="" class="form-control" placeholder="#">
                            <div class="input-group-addon">
                                
                                <select required style="height: 26px;" name="product_id[]" class="selectedDepartment">
                                    <option value=""><?php echo $p_res->macro_name; ?></option>
                                    <?php
                                    if(!empty($product_res)){
                                          foreach($product_res as $res){
                                              ?>
                                              <option value="<?php echo $res->product_id; ?>"><?php echo $res->product_name; ?></option>
                                              <?php
                                          }
                                      }
                                    ?>
                                 </select>
                            </div>
                        </div>
                      </td>
                   <?php
                }
                }
                ?>
                `);          
            newTextBoxDiv.appendTo("#add_emp_dep_box_div");   
            $('#no_of_emp_dep_box').val(langind_box_n);
            langind_box++;
            langind_box_n++;
        });
        $("#remove_emp_dep_box").click(function (){
            langind_box--;
            langind_box_n--;
            langind_box_val = parseInt(langind_box_n)-1; 
            $('#no_of_emp_dep_box').val(langind_box_val);
            $("#rm_langing_box_div" + langind_box).remove();         
            if(langind_box == 1){
                $('#remove_emp_dep_box').hide();
            }
        });
    }); 

   $(document).on('change' , '.selectedDepartment' , function(){

        if(jQuery.inArray($(this).val(), order_Data) !== -1){
            alert('This Engery Resources already selected.please select other Macro');
            $(this).prop("selectedIndex", 0);
            order_Data = $.map($(document).find('select.selectedDepartment'), function(option) {
                return option.value;
            });
            return false;
        }

        order_Data = $.map($(document).find('select.selectedDepartment'), function(option) {
            return option.value;
        });

    });
</script>

