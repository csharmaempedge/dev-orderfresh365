
<aside class="right-side">
   <section class="content-header">
      <h1>Dashboard</h1>
        <ol class="breadcrumb">
           <li><a href="#"><i class="fa fa-dashboard"></i>Home</a></li>
           <li class="active">dashboard</li>
        </ol>
      <?php
      if(!empty($role_id))
      {
        if($role_id == '2')
        {
          
          ?>
          <!-- Main content -->
            <section class="content">       
                <div class="box box-success">
                    <div class="box-header">
                        <div class="pull-left">
                            <h3 class="box-title">Order Details</h3>
                        </div>
                        <div class="pull-right">
                           
                       </div>
                    </div>
                    <form action="" method="post" accept-charset="utf-8" enctype="multipart/form-data">
                        <?php  $csrf = array( 'name' => $this->security->get_csrf_token_name(), 'hash' => $this->security->get_csrf_hash() ); ?>
                        <input type="hidden" name="<?=$csrf['name'];?>" value="<?=$csrf['hash'];?>" />
                        <div class="box-body">
                            <div>
                                <div id="msg_div">
                                    <?php echo $this->session->flashdata('message');?>
                                </div>
                            </div>
                            <div class="row">
                              <div >
                                  <div class="form-group col-md-4">
                                     <div class="input text">
                                         <label>To Date</label>
                                         <div class='input-group'>
                                             <input autocomplete="off" type="text" name="start_date" id="start_date" class="form-control date_val" value="<?php echo (!empty($start_date)) ? $start_date : ''; ?>" onchange="assignEndDate(this.value)">
                                             <span class="input-group-addon">
                                              <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                         </div>
                                     </div>
                                  </div>
                                  <div class="form-group col-md-4">
                                     <div class="input text">
                                         <label>From Date</label>
                                         <div class='input-group' id="show_end_date">
                                            <input autocomplete="off" type="text" name="end_date" id="end_date" class="form-control" value="<?php echo (!empty($end_date)) ? $end_date : ''; ?>" >
                                             <span class="input-group-addon">
                                                 <span class="glyphicon glyphicon-calendar"></span>
                                             </span>
                                         </div>
                                     </div>
                                  </div>
                                  <div class="form-group col-md-2" style="margin-top: 30px;">
                                     <div class="input text">
                                          <button class="btn btn-success btn-sm" type="submit" name="Submit" value="search" >Filter</button>
                                          <a class="btn btn-danger btn-sm" href="<?php echo base_url().MODULE_NAME;?>dashboard">Cancel</a>
                                     </div>
                                  </div> 
                              </div>
                            </div>
                            <div class="table-responsive">
                              <table class="table table-bordered table-striped" id="example_scroll">
                                  <thead>
                                      <tr>
                                        <!-- <th style="background-color: #c8c9e3; color: #22255a;">S.No.</th> -->
                                        <th style="background-color: #c8c9e3; color: #22255a;">Order Date</th>
                                        <th style="background-color: #c8c9e3; color: #22255a;">Item</th>
                                        <th style="background-color: #c8c9e3; color: #22255a;">Total Ordered Plus(lbs)</th>
                                        <th style="background-color: #c8c9e3; color: #22255a;">Total Raw</th>
                                        <!-- <?php
                                        $patient_macro_res = $this->common_model->getData('tbl_macro', NULL, 'multi');
                                        if(!empty($patient_macro_res))
                                        {
                                            foreach ($patient_macro_res as $p_res) 
                                            {
                                                ?><th style="background-color: #c8c9e3; color: #22255a;"><?php echo $p_res->macro_name; ?></th><?php
                                            }
                                        }
                                        ?> -->
                                      </tr>
                                  </thead>
                                  <!-- <tbody>
                                    <?php
                                    if(!empty($start_date) && !empty($end_date))
                                    {
                                      $order_list = $this->common_model->getData('tbl_order_product', array( 'qty !='=>0, 'order_product_created_date >='=>$start_date, 'order_product_created_date <= '=>$end_date), 'multi',NULL,NULL,NULL, 'unique_no');
                                    }
                                    else
                                    {
                                      $order_list = $this->common_model->getData('tbl_order_product', array( 'qty !='=>0), 'multi',NULL,NULL,NULL, 'unique_no');
                                    }
                                    $total_product_price = 0;
                                    if(!empty($order_list))
                                    {
                                        $i = 1;
                                        foreach($order_list as $crt_res)
                                        {
                                          if(!empty($start_date) && !empty($end_date))
                                          {
                                              $product_wise_amount_res = $this->dashboard_model->getOrderProductAmountFilter($crt_res->unique_no, $start_date, $end_date);
                                          }
                                          else
                                          {
                                            $product_wise_amount_res = $this->dashboard_model->getOrderProductAmount($crt_res->unique_no);
                                          }
                                            ?>    
                                            <tr>
                                                <td><?php echo $i; ?></td>
                                                <td>
                                                  <?php echo $crt_res->order_product_created_date;?>
                                                </td>
                                                <td>
                                                  <?php echo $crt_res->qty;?>
                                                </td>
                                                <td>
                                                  <?php 
                                                  $price = $product_wise_amount_res->total_product_price * $crt_res->qty;
                                                  echo $price; ?>
                                                </td>

                                                
                                                    <?php
                                                    foreach ($patient_macro_res as $p_res)
                                                    {
                                                        if(!empty($start_date) && !empty($end_date))
                                                        {
                                                          $cart_res = $this->common_model->getData('tbl_order_product', array('order_product_created_date >='=>$start_date, 'order_product_created_date <= '=>$end_date,'macro_id'=>$p_res->macro_id,'unique_no'=>$crt_res->unique_no), 'multi');
                                                        }
                                                        else
                                                        {
                                                          $cart_res = $this->common_model->getData('tbl_order_product', array('macro_id'=>$p_res->macro_id,'unique_no'=>$crt_res->unique_no), 'multi');
                                                        }
                                                        if(!empty($cart_res))
                                                        {
                                                            foreach ($cart_res as $res) 
                                                            {
                                                                $product_res = $this->common_model->getData('tbl_product', array('product_id'=>$res->product_id), 'single');
                                                                ?><td><?php echo $res->macro_value_id.' - '.$product_res->product_name; ?></td><?php
                                                            }
                                                        }
                                                    }
                                                    ?>
                                                    
                                            </tr>
                                            <?php
                                            $total_product_price = $price + $total_product_price;
                                            $i++;
                                        }
                                    }
                                    else
                                    {
                                        ?>
                                        <tr>
                                            <td colspan="12">No records found...</td>
                                        </tr>
                                        <?php
                                    }
                                    ?>
                                  </tbody> -->
                                  <tbody>
                                    <tr>
                                      <th class="text-right" colspan="2"></th>
                                      <td>
                                        <?php
                                        if(!empty($start_date) && !empty($end_date))
                                        {
                                        $cart_res = $this->common_model->getData('tbl_order_product', array('order_product_created_date >='=>$start_date, 'order_product_created_date <= '=>$end_date), 'multi',NULL,NULL,NULL,'product_id');
                                        }
                                        else
                                        {
                                        $cart_res = $this->common_model->getData('tbl_order_product', NULL, 'multi',NULL,NULL,NULL,'product_id');
                                        }
                                        if(!empty($cart_res))
                                        {   
                                            foreach ($cart_res as $res) 
                                            {
                                                if(!empty($start_date) && !empty($end_date))
                                                {
                                                $opder_res = $this->common_model->getData('tbl_order_product', array('order_product_created_date >='=>$start_date, 'order_product_created_date <= '=>$end_date, 'product_id'=>$res->product_id), 'multi');
                                                }
                                                else
                                                {
                                                $opder_res = $this->common_model->getData('tbl_order_product', array('product_id'=>$res->product_id), 'multi');
                                                }
                                                $cc=0;
                                                foreach ($opder_res as $oo_res) 
                                                {
                                                    if(!empty($start_date) && !empty($end_date))
                                                    {
                                                    $op_res = $this->common_model->getData('tbl_order_product', array('order_product_created_date >='=>$start_date, 'order_product_created_date <= '=>$end_date,'qty !='=>0,'unique_no'=>$oo_res->unique_no), 'single');
                                                    }
                                                    else
                                                    {
                                                      $op_res = $this->common_model->getData('tbl_order_product', array( 'qty !='=>0,'unique_no'=>$oo_res->unique_no), 'single');
                                                    }
                                                    $product_res = $this->common_model->getData('tbl_product', array('product_id'=>$oo_res->product_id), 'single');
                                                    $aa = $oo_res->macro_value_id * $op_res->qty;
                                                    $cc = $cc + $aa;
                                                    $product_plus_percentage = ($product_res->product_plus_percentage * $cc)/100;
                                                    $plus_percentage = $product_plus_percentage + $cc;
                                                    $product_row_amount = $plus_percentage * $product_res->product_row_amount;
                                                }
                                                ?>
                                                <tr>
                                                    <td style="background-color: #bad59c; color: #22255a;"><b>
                                                      <?php echo $op_res->order_product_created_date;?></b>
                                                    </td>
                                                    <td style="background-color: #bad59c; color: #22255a;"><b><?php echo $product_res->product_name; ?></b></td>
                                                    <!-- <td style="background-color: #bad59c; color: #22255a;"><b><?php echo $cc; ?></b></td> -->
                                                    <td style="background-color: #bad59c; color: #22255a;"><b><?php echo round($plus_percentage, 2); ?></b></td>
                                                    <td style="background-color: #bad59c; color: #22255a;"><b><?php echo round($product_row_amount, 2); ?></b></td>
                                                    
                                                </tr>
                                                <?php
                                            }
                                        }
                                            ?>
                                      </td>
                                      <td></td>
                                      <td></td>
                                      <td></td>
                                    </tr>

                                    <div class="clearfix" ></div>
                                <hr>
                                  </tbody>
                              </table>
                            </div> 
                        </div>
                    </form>
                </div>

                <!-- /.box -->
            </section>
            <!-- /.content -->
          <?php
        }
      }
      ?>
   </section>
</aside>
<script type="text/javascript">
  function assignEndDate(str)
    {
       $('#show_end_date').html('<input  autocomplete="off" type="text" name="end_date" id="end_date" class="form-control date_val"><span class="input-group-addon"><span class="glyphicon glyphicon-calendar"></span></span>');
       min1 = new Date(str);
       min = new Date(str);
       var numberOfDaysToAdd = 0;
       min.setDate(min.getDate() + numberOfDaysToAdd);
       var dd = min.getDate();
       var mm = min.getMonth() + 1;
       var y = min.getFullYear();
       var aa = y+'-'+mm+'-'+dd;
       max = new Date(aa); 

       $( "#end_date" ).datepicker({ 
          minDate: min1,
          //maxDate: max,
          dateFormat : 'yy-mm-dd',
          changeMonth : true,
          changeYear : true,
       });
    }
</script>

